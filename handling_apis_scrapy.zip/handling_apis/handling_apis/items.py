import scrapy

class ApiScraperItem(scrapy.Item):
    """
    Item class for storing API data scraped from various sources.
    """
    userId = scrapy.Field()
    id = scrapy.Field()
    title = scrapy.Field()
    body = scrapy.Field()