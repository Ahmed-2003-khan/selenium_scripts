import scrapy

class BookscraperItem(scrapy.Item):
    # Define the fields for your item here like:
    title = scrapy.Field()
    price = scrapy.Field()
    rating = scrapy.Field()