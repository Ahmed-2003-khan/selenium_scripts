import scrapy

class QuoteItem(scrapy.Item):
    """Item to store quotes scraped from the website."""
    text = scrapy.Field()  # The text of the quote
    author = scrapy.Field()  # The author of the quote
    tags = scrapy.Field()  # Tags associated with the quote
